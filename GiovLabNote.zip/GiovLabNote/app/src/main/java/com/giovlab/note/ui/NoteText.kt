package com.giovlab.note.ui

import android.content.Context
import android.content.Intent
import com.giovlab.note.data.Note
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val italian = Locale.ITALY

/** "05:20" oggi, "ieri", "27 ott" quest'anno, "27 ott 2025" altrimenti. */
fun formatShort(time: Long): String {
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = time }
    val yesterday = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }

    fun Calendar.sameDay(o: Calendar) =
        get(Calendar.YEAR) == o.get(Calendar.YEAR) &&
            get(Calendar.DAY_OF_YEAR) == o.get(Calendar.DAY_OF_YEAR)

    val pattern = when {
        then.sameDay(now) -> "HH:mm"
        then.sameDay(yesterday) -> return "ieri"
        then.get(Calendar.YEAR) == now.get(Calendar.YEAR) -> "d MMM"
        else -> "d MMM yyyy"
    }
    return SimpleDateFormat(pattern, italian).format(Date(time))
}

/** Una riga di anteprima del contenuto. */
fun Note.preview(): String =
    if (isChecklist) {
        items.filter { !it.checked }.joinToString(", ") { it.text }
            .ifEmpty { if (items.isNotEmpty()) "Tutto completato" else "" }
    } else {
        content.lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
    }

/** Testo semplice da condividere con altre app. */
fun Note.shareText(): String {
    val body = if (isChecklist) {
        items.joinToString("\n") { (if (it.checked) "☑ " else "☐ ") + it.text }
    } else content.trim()
    return listOf(title.trim(), body).filter { it.isNotEmpty() }.joinToString("\n\n")
}

fun shareNote(context: Context, note: Note) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        if (note.title.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, note.title.trim())
        putExtra(Intent.EXTRA_TEXT, note.shareText())
    }
    context.startActivity(Intent.createChooser(send, "Condividi nota"))
}
