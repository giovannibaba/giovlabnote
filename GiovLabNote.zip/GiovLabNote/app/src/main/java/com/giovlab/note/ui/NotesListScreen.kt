package com.giovlab.note.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.giovlab.note.data.Note
import com.giovlab.note.ui.theme.NoteColors
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesListScreen(
    vm: NotesViewModel,
    onOpen: (Long) -> Unit,
    onNew: () -> Unit
) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    val labels by vm.labels.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val selected by vm.selectedLabel.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var searching by rememberSaveable { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var editingLabel by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) vm.exportTo(uri) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.importFrom(uri) }

    Scaffold(
        topBar = {
            if (searching) {
                SearchBar(
                    query = query,
                    onQuery = { vm.query.value = it },
                    onClose = { searching = false; vm.query.value = "" }
                )
            } else {
                LargeTopAppBar(
                    title = { Text("Note", fontWeight = FontWeight.Medium) },
                    actions = {
                        IconButton(onClick = { searching = true }) {
                            Icon(Icons.Default.Search, "Cerca")
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, "Altre opzioni")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("Esporta backup") },
                                    leadingIcon = { Icon(Icons.Outlined.FileUpload, null) },
                                    onClick = {
                                        menuOpen = false
                                        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.ITALY).format(Date())
                                        exportLauncher.launch("giovlab-note-$stamp.json")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Importa backup") },
                                    leadingIcon = { Icon(Icons.Outlined.FileDownload, null) },
                                    onClick = {
                                        menuOpen = false
                                        importLauncher.launch(
                                            arrayOf("application/json", "application/octet-stream", "text/plain")
                                        )
                                    }
                                )
                            }
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNew,
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.onSurface,
                contentColor = MaterialTheme.colorScheme.surface,
                elevation = FloatingActionButtonDefaults.elevation(0.dp, 0.dp, 0.dp, 0.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Nuova nota")
            }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            if (labels.isNotEmpty() && !searching) {
                item {
                    LabelFilter(
                        labels = labels,
                        selected = selected,
                        onSelect = { vm.selectedLabel.value = it },
                        onEdit = { editingLabel = it }
                    )
                }
            }

            if (notes.isEmpty()) {
                item {
                    Box(
                        Modifier.fillParentMaxHeight(0.6f).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            when {
                                query.isNotBlank() -> "Nessun risultato"
                                selected != null -> "Nessuna nota con questa etichetta"
                                else -> "Nessuna nota"
                            },
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }

            itemsIndexed(notes, key = { _, n -> n.id }) { index, note ->
                NoteRow(
                    note = note,
                    onClick = { onOpen(note.id) },
                    onTogglePin = { vm.togglePin(note) },
                    onShare = { shareNote(context, note) },
                    onDelete = {
                        vm.delete(note)
                        scope.launch {
                            val r = snackbar.showSnackbar("Nota eliminata", actionLabel = "Annulla")
                            if (r == SnackbarResult.ActionPerformed) vm.restore(note)
                        }
                    }
                )
                if (index < notes.lastIndex) {
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 24.dp),
                        thickness = 0.5.dp,
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                }
            }
        }
    }

    editingLabel?.let { old ->
        LabelEditDialog(
            name = old,
            onDismiss = { editingLabel = null },
            onRename = { vm.renameLabel(old, it); editingLabel = null },
            onDelete = { vm.deleteLabel(old); editingLabel = null }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchBar(query: String, onQuery: (String) -> Unit, onClose: () -> Unit) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    TopAppBar(
        navigationIcon = {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Chiudi ricerca") }
        },
        title = {
            TextField(
                value = query,
                onValueChange = onQuery,
                placeholder = { Text("Cerca") },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
        },
        actions = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQuery("") }) { Icon(Icons.Default.Close, "Cancella") }
            }
        }
    )
}

/** Filtro etichette come semplici parole. Pressione lunga per rinominare o eliminare. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LabelFilter(
    labels: List<String>,
    selected: String?,
    onSelect: (String?) -> Unit,
    onEdit: (String) -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 6.dp)
    ) {
        FilterWord("Tutte", selected == null, onClick = { onSelect(null) }, onLongClick = null)
        labels.forEach { label ->
            FilterWord(
                text = label,
                active = selected == label,
                onClick = { onSelect(if (selected == label) null else label) },
                onLongClick = { onEdit(label) }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FilterWord(text: String, active: Boolean, onClick: () -> Unit, onLongClick: (() -> Unit)?) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = if (active) FontWeight.Medium else FontWeight.Normal,
        color = if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline,
        modifier = Modifier
            .clip(MaterialTheme.shapes.small)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(vertical = 6.dp)
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NoteRow(
    note: Note,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val preview = note.preview()
    val title = note.title.ifBlank { preview.ifBlank { "Senza titolo" } }
    val showPreview = note.title.isNotBlank() && preview.isNotBlank()

    val open = note.items.count { !it.checked }
    val meta = buildList {
        if (note.labels.isNotEmpty()) add(note.labels.joinToString(", "))
        if (note.isChecklist && open > 0) add("$open da fare")
        add(formatShort(note.updatedAt))
    }.joinToString(" · ")

    Box {
        Column(
            Modifier
                .fillMaxWidth()
                .combinedClickable(onClick = onClick, onLongClick = { menu = true })
                .padding(horizontal = 24.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NoteColors.dot(note.color)?.let { c ->
                    Box(Modifier.size(8.dp).clip(CircleShape).background(c))
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (note.pinned) {
                    Spacer(Modifier.width(6.dp))
                    Icon(
                        Icons.Outlined.PushPin, "Fissata",
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
            if (showPreview) {
                Spacer(Modifier.height(2.dp))
                Text(
                    preview,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(meta, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        }

        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(if (note.pinned) "Rimuovi da in alto" else "Fissa in alto") },
                leadingIcon = { Icon(Icons.Outlined.PushPin, null) },
                onClick = { menu = false; onTogglePin() }
            )
            DropdownMenuItem(
                text = { Text("Condividi") },
                leadingIcon = { Icon(Icons.Outlined.Share, null) },
                onClick = { menu = false; onShare() }
            )
            DropdownMenuItem(
                text = { Text("Elimina") },
                leadingIcon = { Icon(Icons.Outlined.Delete, null) },
                onClick = { menu = false; onDelete() }
            )
        }
    }
}

@Composable
private fun LabelEditDialog(
    name: String,
    onDismiss: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit
) {
    var text by remember { mutableStateOf(name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modifica etichetta") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    label = { Text("Nome") }
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Se la elimini, le note restano: viene tolta solo l'etichetta.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onRename(text) }, enabled = text.isNotBlank()) { Text("Rinomina") }
        },
        dismissButton = {
            TextButton(onClick = onDelete) { Text("Elimina", color = MaterialTheme.colorScheme.error) }
        }
    )
}
