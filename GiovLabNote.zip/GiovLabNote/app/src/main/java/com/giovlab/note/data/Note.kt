package com.giovlab.note.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import kotlin.random.Random

@Serializable
data class ChecklistItem(
    val id: Long = Random.nextLong(),
    val text: String = "",
    val checked: Boolean = false
)

@Serializable
@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val pinned: Boolean = false,
    /** Indice nella palette [com.giovlab.note.ui.theme.NoteColors]. */
    val color: Int = 0,
    val labels: List<String> = emptyList(),
    val isChecklist: Boolean = false,
    val items: List<ChecklistItem> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

val Note.isEmpty: Boolean
    get() = title.isBlank() && content.isBlank() && items.none { it.text.isNotBlank() }

/** Stesso contenuto, ignorando id e data di modifica. */
fun Note.sameContentAs(other: Note): Boolean =
    copy(id = 0, updatedAt = 0) == other.copy(id = 0, updatedAt = 0)

fun Note.matches(query: String): Boolean =
    query.isEmpty() ||
        title.contains(query, ignoreCase = true) ||
        content.contains(query, ignoreCase = true) ||
        labels.any { it.contains(query, ignoreCase = true) } ||
        items.any { it.text.contains(query, ignoreCase = true) }
