package com.giovlab.note.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.giovlab.note.data.BackupFormat
import com.giovlab.note.data.Note
import com.giovlab.note.data.NoteDatabase
import com.giovlab.note.data.matches
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Stato della schermata con l'elenco delle note. */
class NotesViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = NoteDatabase.get(app).noteDao()
    private val all = dao.observeAll()

    val query = MutableStateFlow("")
    val selectedLabel = MutableStateFlow<String?>(null)

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    val labels: StateFlow<List<String>> = all
        .map { list -> list.flatMap { it.labels }.distinct().sortedBy { it.lowercase() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val notes: StateFlow<List<Note>> = combine(all, query, selectedLabel) { list, q, label ->
        val text = q.trim()
        list.filter { (label == null || label in it.labels) && it.matches(text) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun togglePin(note: Note) = viewModelScope.launch {
        dao.upsert(note.copy(pinned = !note.pinned))
    }

    fun delete(note: Note) = viewModelScope.launch { dao.delete(note) }

    fun restore(note: Note) = viewModelScope.launch { dao.upsert(note) }

    // --- Etichette ---

    fun renameLabel(old: String, newName: String) = viewModelScope.launch {
        val name = newName.trim()
        if (name.isEmpty() || name == old) return@launch
        val changed = dao.getAll()
            .filter { old in it.labels }
            .map { n -> n.copy(labels = n.labels.map { if (it == old) name else it }.distinct()) }
        dao.upsertAll(changed)
        if (selectedLabel.value == old) selectedLabel.value = name
    }

    fun deleteLabel(name: String) = viewModelScope.launch {
        val changed = dao.getAll()
            .filter { name in it.labels }
            .map { it.copy(labels = it.labels - name) }
        dao.upsertAll(changed)
        if (selectedLabel.value == name) selectedLabel.value = null
    }

    // --- Backup ---

    fun exportTo(uri: Uri) = viewModelScope.launch {
        val result = runCatching {
            withContext(Dispatchers.IO) {
                val notes = dao.getAll()
                val stream = getApplication<Application>().contentResolver.openOutputStream(uri)
                    ?: error("Impossibile aprire il file")
                stream.use { it.write(BackupFormat.encode(notes).toByteArray()) }
                notes.size
            }
        }
        _messages.emit(
            result.fold(
                onSuccess = { "Backup salvato ($it note)" },
                onFailure = { "Esportazione non riuscita" }
            )
        )
    }

    fun importFrom(uri: Uri) = viewModelScope.launch {
        val result = runCatching {
            withContext(Dispatchers.IO) {
                val text = getApplication<Application>().contentResolver.openInputStream(uri)
                    ?.use { it.readBytes().decodeToString() }
                    ?: error("Impossibile aprire il file")
                val imported = BackupFormat.decode(text)
                dao.upsertAll(BackupFormat.merge(imported, dao.getAll()))
                imported.size
            }
        }
        _messages.emit(
            result.fold(
                onSuccess = { "Importate $it note" },
                onFailure = { "File di backup non valido" }
            )
        )
    }
}
