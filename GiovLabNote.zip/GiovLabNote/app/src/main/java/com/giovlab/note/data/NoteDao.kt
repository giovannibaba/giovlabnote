package com.giovlab.note.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {

    @Query("SELECT * FROM notes ORDER BY pinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<Note>>

    @Query("SELECT * FROM notes")
    suspend fun getAll(): List<Note>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getById(id: Long): Note?

    /** Restituisce il nuovo id se inserisce, -1 se aggiorna. */
    @Upsert
    suspend fun upsert(note: Note): Long

    @Upsert
    suspend fun upsertAll(notes: List<Note>)

    @Delete
    suspend fun delete(note: Note)
}
