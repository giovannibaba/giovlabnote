package com.giovlab.note.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Label
import androidx.compose.material.icons.automirrored.outlined.Notes
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.giovlab.note.data.ChecklistItem
import com.giovlab.note.ui.theme.NoteColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditScreen(
    onDone: () -> Unit,
    vm: NoteEditorViewModel = viewModel()
) {
    val context = LocalContext.current
    val exit = {
        vm.save()
        onDone()
    }
    BackHandler(onBack = exit)
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.save() }

    var menu by remember { mutableStateOf(false) }
    var showColors by remember { mutableStateOf(false) }
    var showLabels by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val plain = TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent,
        unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent
    )
    val muted = MaterialTheme.colorScheme.outline

    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = {
                    IconButton(onClick = exit) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                actions = {
                    IconButton(onClick = { vm.pinned = !vm.pinned }) {
                        Icon(
                            if (vm.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            if (vm.pinned) "Rimuovi da in alto" else "Fissa in alto"
                        )
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Altre opzioni") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("Colore") },
                                leadingIcon = { Icon(Icons.Outlined.Palette, null) },
                                onClick = { menu = false; showColors = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Etichette") },
                                leadingIcon = { Icon(Icons.AutoMirrored.Outlined.Label, null) },
                                onClick = { menu = false; showLabels = true }
                            )
                            DropdownMenuItem(
                                text = { Text(if (vm.isChecklist) "Converti in testo" else "Converti in checklist") },
                                leadingIcon = {
                                    Icon(if (vm.isChecklist) Icons.AutoMirrored.Outlined.Notes else Icons.Outlined.TaskAlt, null)
                                },
                                onClick = { menu = false; vm.toggleChecklist() }
                            )
                            DropdownMenuItem(
                                text = { Text("Condividi") },
                                leadingIcon = { Icon(Icons.Outlined.Share, null) },
                                onClick = { menu = false; shareNote(context, vm.draft()) }
                            )
                            DropdownMenuItem(
                                text = { Text("Elimina") },
                                leadingIcon = { Icon(Icons.Outlined.Delete, null) },
                                onClick = { menu = false; confirmDelete = true }
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (!vm.loaded) return@Scaffold

        LazyColumn(
            Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
                .fillMaxSize()
        ) {
            item {
                TextField(
                    value = vm.title,
                    onValueChange = { vm.title = it },
                    placeholder = { Text("Titolo", style = MaterialTheme.typography.headlineSmall) },
                    textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Medium),
                    colors = plain,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
            }

            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 12.dp)
                        .clickable { showLabels = true }
                ) {
                    NoteColors.dot(vm.color)?.let { c ->
                        Box(Modifier.size(7.dp).clip(CircleShape).background(c))
                        Spacer(Modifier.width(6.dp))
                    }
                    val meta = buildList {
                        if (vm.labels.isNotEmpty()) add(vm.labels.joinToString(", "))
                        add("Modificata " + formatShort(vm.updatedAt).let { if (it.contains(':')) "alle $it" else it })
                    }.joinToString(" · ")
                    Text(meta, style = MaterialTheme.typography.labelSmall, color = muted)
                }
            }

            if (!vm.isChecklist) {
                item {
                    TextField(
                        value = vm.content,
                        onValueChange = { vm.content = it },
                        placeholder = { Text("Scrivi qui…") },
                        colors = plain,
                        textStyle = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 320.dp)
                            .padding(horizontal = 8.dp)
                    )
                }
            } else {
                val open = vm.items.filter { !it.checked }
                val done = vm.items.filter { it.checked }

                items(open, key = { it.id }) { item ->
                    ChecklistRow(
                        item = item,
                        requestFocus = vm.focusItemId == item.id,
                        onFocused = { vm.focusItemId = null },
                        onText = { vm.updateItem(item.id, it) },
                        onToggle = { vm.toggleItem(item.id) },
                        onRemove = { vm.removeItem(item.id) },
                        onNext = { vm.addItem(after = item.id) },
                        colors = plain
                    )
                }
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { vm.addItem() }
                            .padding(horizontal = 24.dp, vertical = 12.dp)
                    ) {
                        Icon(Icons.Default.Add, null, tint = muted, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(16.dp))
                        Text("Aggiungi", color = muted)
                    }
                }
                items(done, key = { it.id }) { item ->
                    ChecklistRow(
                        item = item,
                        requestFocus = false,
                        onFocused = {},
                        onText = { vm.updateItem(item.id, it) },
                        onToggle = { vm.toggleItem(item.id) },
                        onRemove = { vm.removeItem(item.id) },
                        onNext = {},
                        colors = plain
                    )
                }
            }
        }
    }

    if (showColors) {
        ModalBottomSheet(onDismissRequest = { showColors = false }) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 16.dp)
                    .padding(bottom = 16.dp)
            ) {
                repeat(NoteColors.count) { i ->
                    val selected = vm.color == i
                    val dot = NoteColors.dot(i)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .border(
                                width = if (selected) 2.dp else 0.dp,
                                color = if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { vm.color = i }
                            .semantics { contentDescription = NoteColors.names[i] }
                    ) {
                        if (dot != null) {
                            Box(Modifier.size(26.dp).clip(CircleShape).background(dot))
                        } else {
                            Icon(Icons.Outlined.Block, null, tint = muted)
                        }
                    }
                }
            }
        }
    }

    if (showLabels) {
        val allLabels by vm.allLabels.collectAsStateWithLifecycle()
        LabelsDialog(
            all = allLabels,
            selected = vm.labels,
            onToggle = vm::toggleLabel,
            onAdd = vm::addLabel,
            onDismiss = { showLabels = false }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Eliminare la nota?") },
            text = { Text("L'operazione non si può annullare.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.delete()
                    onDone()
                }) { Text("Elimina", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Annulla") }
            }
        )
    }
}

@Composable
private fun ChecklistRow(
    item: ChecklistItem,
    requestFocus: Boolean,
    onFocused: () -> Unit,
    onText: (String) -> Unit,
    onToggle: () -> Unit,
    onRemove: () -> Unit,
    onNext: () -> Unit,
    colors: TextFieldColors
) {
    val focus = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(requestFocus) {
        if (requestFocus) {
            runCatching { focus.requestFocus() }
            onFocused()
        }
    }
    val muted = MaterialTheme.colorScheme.outline
    val doneColor = MaterialTheme.colorScheme.outlineVariant

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp)
    ) {
        IconButton(onClick = onToggle) {
            Icon(
                if (item.checked) Icons.Outlined.CheckCircle else Icons.Outlined.Circle,
                contentDescription = if (item.checked) "Segna da fare" else "Segna come fatto",
                tint = muted,
                modifier = Modifier.size(20.dp)
            )
        }
        TextField(
            value = item.text,
            onValueChange = { text ->
                if (text.contains('\n')) {
                    onText(text.replace("\n", ""))
                    onNext()
                } else onText(text)
            },
            placeholder = { Text("Elemento") },
            textStyle = MaterialTheme.typography.bodyLarge.copy(
                textDecoration = if (item.checked) TextDecoration.LineThrough else null,
                color = if (item.checked) muted else MaterialTheme.colorScheme.onSurface
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { onNext() }),
            colors = colors,
            modifier = Modifier
                .weight(1f)
                .focusRequester(focus)
                .onFocusChanged { focused = it.isFocused }
        )
        // La X compare solo sull'elemento che stai modificando
        if (focused) {
            IconButton(onClick = onRemove) {
                Icon(Icons.Default.Close, "Rimuovi elemento", tint = muted, modifier = Modifier.size(18.dp))
            }
        } else {
            Spacer(Modifier.size(48.dp))
        }
    }
}

@Composable
private fun LabelsDialog(
    all: List<String>,
    selected: List<String>,
    onToggle: (String) -> Unit,
    onAdd: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var newLabel by remember { mutableStateOf("") }
    val options = (all + selected).distinct().sortedBy { it.lowercase() }
    val add = {
        onAdd(newLabel)
        newLabel = ""
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Etichette") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fatto") } },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newLabel,
                        onValueChange = { newLabel = it },
                        placeholder = { Text("Nuova etichetta") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { add() }),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = add, enabled = newLabel.isNotBlank()) {
                        Icon(Icons.Default.Add, "Aggiungi etichetta")
                    }
                }
                if (options.isNotEmpty()) {
                    LazyColumn(Modifier.heightIn(max = 300.dp).padding(top = 8.dp)) {
                        items(options, key = { it }) { label ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth().clickable { onToggle(label) }
                            ) {
                                Checkbox(checked = label in selected, onCheckedChange = { onToggle(label) })
                                Text(label)
                            }
                        }
                    }
                }
            }
        }
    )
}
