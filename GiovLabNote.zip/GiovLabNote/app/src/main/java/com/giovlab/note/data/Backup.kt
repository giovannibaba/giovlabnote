package com.giovlab.note.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class Backup(
    val app: String = "GiovLab Note",
    val version: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val notes: List<Note>
)

object BackupFormat {
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun encode(notes: List<Note>): String =
        json.encodeToString(Backup.serializer(), Backup(notes = notes))

    fun decode(text: String): List<Note> =
        json.decodeFromString(Backup.serializer(), text).notes

    /**
     * Prepara le note importate per il salvataggio senza duplicati:
     * una nota con la stessa data di creazione di una già presente la aggiorna,
     * le altre vengono aggiunte come nuove.
     */
    fun merge(imported: List<Note>, local: List<Note>): List<Note> {
        val byCreated = local.associateBy { it.createdAt }
        return imported.map { n ->
            val match = byCreated[n.createdAt]
            n.copy(id = match?.id ?: 0)
        }
    }
}
