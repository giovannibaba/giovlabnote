package com.giovlab.note.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.giovlab.note.data.AppScope
import com.giovlab.note.data.ChecklistItem
import com.giovlab.note.data.Note
import com.giovlab.note.data.NoteDatabase
import com.giovlab.note.data.isEmpty
import com.giovlab.note.data.sameContentAs
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Stato dell'editor di una singola nota. Vive finché la schermata è aperta
 * (sopravvive alla rotazione) e salva in automatico.
 */
class NoteEditorViewModel(
    app: Application,
    handle: SavedStateHandle
) : AndroidViewModel(app) {

    private val dao = NoteDatabase.get(app).noteDao()
    private val saveLock = Mutex()

    @Volatile private var currentId: Long? = handle.get<Long>("id")?.takeIf { it > 0 }
    private var createdAt = System.currentTimeMillis()
    private var lastSaved: Note? = null
    private var deleted = false

    var loaded by mutableStateOf(currentId == null)
        private set

    var title by mutableStateOf("")
    var content by mutableStateOf("")
    var pinned by mutableStateOf(false)
    var color by mutableIntStateOf(0)
    var isChecklist by mutableStateOf(false)
        private set
    val items = mutableStateListOf<ChecklistItem>()
    val labels = mutableStateListOf<String>()
    var updatedAt by mutableLongStateOf(System.currentTimeMillis())
        private set

    /** Elemento della checklist che deve ricevere il focus. */
    var focusItemId by mutableStateOf<Long?>(null)

    val allLabels: StateFlow<List<String>> = dao.observeAll()
        .map { list -> list.flatMap { it.labels }.distinct().sortedBy { it.lowercase() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        currentId?.let { id ->
            viewModelScope.launch {
                dao.getById(id)?.let(::fill)
                loaded = true
            }
        }
    }

    private fun fill(n: Note) {
        title = n.title
        content = n.content
        pinned = n.pinned
        color = n.color
        isChecklist = n.isChecklist
        items.clear(); items.addAll(n.items)
        labels.clear(); labels.addAll(n.labels)
        createdAt = n.createdAt
        updatedAt = n.updatedAt
        lastSaved = n
    }

    /** La nota così com'è adesso nell'editor (usata anche per condividerla). */
    fun draft() = Note(
        id = currentId ?: 0,
        title = title.trim(),
        content = if (isChecklist) "" else content,
        pinned = pinned,
        color = color,
        labels = labels.toList(),
        isChecklist = isChecklist,
        items = if (isChecklist) items.filter { it.text.isNotBlank() } else emptyList(),
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    // --- Checklist ---

    fun toggleChecklist() {
        if (isChecklist) {
            content = items.joinToString("\n") { it.text }.trim()
            items.clear()
            isChecklist = false
        } else {
            val lines = content.lines()
                .map { it.trim().removePrefix("- ").removePrefix("• ").trim() }
                .filter { it.isNotEmpty() }
            items.clear()
            if (lines.isEmpty()) {
                val first = ChecklistItem()
                items.add(first)
                focusItemId = first.id
            } else {
                items.addAll(lines.map { ChecklistItem(text = it) })
            }
            content = ""
            isChecklist = true
        }
    }

    fun addItem(after: Long? = null) {
        val item = ChecklistItem()
        val index = after?.let { id -> items.indexOfFirst { it.id == id } } ?: -1
        if (index >= 0) items.add(index + 1, item) else items.add(item)
        focusItemId = item.id
    }

    fun updateItem(id: Long, text: String) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) items[i] = items[i].copy(text = text)
    }

    fun toggleItem(id: Long) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) items[i] = items[i].copy(checked = !items[i].checked)
    }

    fun removeItem(id: Long) {
        items.removeAll { it.id == id }
    }

    // --- Etichette ---

    fun toggleLabel(name: String) {
        if (name in labels) labels.remove(name) else labels.add(name)
    }

    fun addLabel(raw: String) {
        val name = raw.trim()
        if (name.isNotEmpty() && name !in labels) labels.add(name)
    }

    // --- Salvataggio ---

    /** Salva solo se ci sono modifiche. Sicuro da chiamare più volte. */
    fun save() {
        if (!loaded || deleted) return
        val draft = draft()
        val previous = lastSaved
        if (previous == null && draft.isEmpty) return
        if (previous != null && draft.sameContentAs(previous)) return

        val toSave = draft.copy(updatedAt = System.currentTimeMillis())
        lastSaved = toSave
        updatedAt = toSave.updatedAt

        AppScope.io.launch {
            saveLock.withLock {
                val newId = dao.upsert(toSave.copy(id = currentId ?: 0))
                if (currentId == null && newId > 0) currentId = newId
            }
        }
    }

    fun delete() {
        deleted = true
        AppScope.io.launch {
            saveLock.withLock {
                currentId?.let { id -> dao.getById(id)?.let { dao.delete(it) } }
            }
        }
    }
}
