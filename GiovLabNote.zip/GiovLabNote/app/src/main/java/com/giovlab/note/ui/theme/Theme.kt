package com.giovlab.note.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Tema monocromatico: bianco e nero, nessun colore dinamico. */
private val Light = lightColorScheme(
    primary = Color(0xFF1F1F1D),
    onPrimary = Color.White,
    secondaryContainer = Color(0xFFEDEDEB),
    onSecondaryContainer = Color(0xFF1F1F1D),
    background = Color.White,
    onBackground = Color(0xFF1F1F1D),
    surface = Color.White,
    onSurface = Color(0xFF1F1F1D),
    onSurfaceVariant = Color(0xFF5F5E5A),
    surfaceTint = Color.White,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF8F8F6),
    surfaceContainer = Color(0xFFF4F4F2),
    surfaceContainerHigh = Color(0xFFEEEEEC),
    surfaceContainerHighest = Color(0xFFE8E8E6),
    outline = Color(0xFF9A9994),
    outlineVariant = Color(0xFFE6E5E0)
)

private val Dark = darkColorScheme(
    primary = Color(0xFFEDEDEB),
    onPrimary = Color(0xFF121212),
    secondaryContainer = Color(0xFF2A2A2A),
    onSecondaryContainer = Color(0xFFEDEDEB),
    background = Color(0xFF121212),
    onBackground = Color(0xFFEDEDEB),
    surface = Color(0xFF121212),
    onSurface = Color(0xFFEDEDEB),
    onSurfaceVariant = Color(0xFFB4B2A9),
    surfaceTint = Color(0xFF121212),
    surfaceContainerLowest = Color(0xFF0E0E0E),
    surfaceContainerLow = Color(0xFF181818),
    surfaceContainer = Color(0xFF1C1C1C),
    surfaceContainerHigh = Color(0xFF242424),
    surfaceContainerHighest = Color(0xFF2C2C2C),
    outline = Color(0xFF7A7973),
    outlineVariant = Color(0xFF2E2E2C)
)

@Composable
fun GiovLabNoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content
    )
}
