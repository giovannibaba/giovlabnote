package com.giovlab.note.data

import androidx.room.TypeConverter
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

/** Salva liste di etichette ed elementi checklist come JSON in una colonna di testo. */
class Converters {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val labelsSer = ListSerializer(String.serializer())
    private val itemsSer = ListSerializer(ChecklistItem.serializer())

    @TypeConverter
    fun fromLabels(value: List<String>): String = json.encodeToString(labelsSer, value)

    @TypeConverter
    fun toLabels(value: String): List<String> =
        runCatching { json.decodeFromString(labelsSer, value) }.getOrDefault(emptyList())

    @TypeConverter
    fun fromItems(value: List<ChecklistItem>): String = json.encodeToString(itemsSer, value)

    @TypeConverter
    fun toItems(value: String): List<ChecklistItem> =
        runCatching { json.decodeFromString(itemsSer, value) }.getOrDefault(emptyList())
}
