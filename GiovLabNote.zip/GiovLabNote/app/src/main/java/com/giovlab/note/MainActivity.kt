package com.giovlab.note

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.giovlab.note.ui.NoteEditScreen
import com.giovlab.note.ui.NotesListScreen
import com.giovlab.note.ui.NotesViewModel
import com.giovlab.note.ui.theme.GiovLabNoteTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GiovLabNoteTheme {
                val nav = rememberNavController()
                val listVm: NotesViewModel = viewModel()

                NavHost(nav, startDestination = "list") {
                    composable("list") {
                        NotesListScreen(
                            vm = listVm,
                            onOpen = { id -> nav.navigate("edit?id=$id") },
                            onNew = { nav.navigate("edit") }
                        )
                    }
                    composable(
                        "edit?id={id}",
                        arguments = listOf(navArgument("id") {
                            type = NavType.LongType
                            defaultValue = -1L
                        })
                    ) {
                        // L'editor ha un proprio ViewModel legato a questa schermata
                        NoteEditScreen(
                            onDone = {
                                if (nav.currentDestination?.route?.startsWith("edit") == true) {
                                    nav.popBackStack()
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
