package com.giovlab.note.ui.theme

import androidx.compose.ui.graphics.Color

/** Colori delle note, mostrati solo come un piccolo punto. L'indice 0 = nessun colore. */
object NoteColors {
    val names = listOf(
        "Nessuno", "Rosso", "Arancione", "Giallo", "Verde",
        "Azzurro", "Blu", "Viola", "Grigio"
    )

    private val dots = listOf(
        Color.Unspecified,
        Color(0xFFE57373), Color(0xFFFFB74D), Color(0xFFFFD54F), Color(0xFF81C784),
        Color(0xFF4FC3F7), Color(0xFF7986CB), Color(0xFFBA68C8), Color(0xFF9E9E9E)
    )

    val count: Int get() = names.size

    fun dot(index: Int): Color? =
        dots.getOrNull(index)?.takeIf { it != Color.Unspecified }
}
