package com.giovlab.note.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Scope che sopravvive alla chiusura di una schermata: i salvataggi non vengono interrotti. */
object AppScope {
    val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
}
